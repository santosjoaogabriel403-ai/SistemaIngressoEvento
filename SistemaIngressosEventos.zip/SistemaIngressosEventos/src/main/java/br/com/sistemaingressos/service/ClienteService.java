package br.com.sistemaingressos.service;

import br.com.sistemaingressos.model.Cliente;
import br.com.sistemaingressos.repository.ClienteRepository;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {

    private final ClienteRepository repository;

    public ClienteService(ClienteRepository repository) {
        this.repository = repository;
    }

    public Cliente cadastrar(String nome, String email, String senha) {
        Cliente clienteExistente = repository.findByEmail(email).orElse(null);

        if (clienteExistente != null) {
            return clienteExistente;
        }

        Cliente cliente = new Cliente(nome, email, senha);
        return repository.save(cliente);
    }

    public Cliente login(String email, String senha) {
        Cliente cliente = repository.findByEmail(email).orElse(null);

        if (cliente == null) {
            return null;
        }

        if (!cliente.getSenha().equals(senha)) {
            return null;
        }

        return cliente;
    }
}