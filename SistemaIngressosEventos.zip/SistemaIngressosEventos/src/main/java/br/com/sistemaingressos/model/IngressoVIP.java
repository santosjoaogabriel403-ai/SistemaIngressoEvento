package br.com.sistemaingressos.model;

import org.springframework.data.annotation.TypeAlias;

@TypeAlias("vip")
public class IngressoVIP extends Ingresso {

    public IngressoVIP() {
        setTipo("VIP");
    }

    public IngressoVIP(String evento, String comprador, double valorBase) {
        super(evento, comprador, valorBase);
        setTipo("VIP");
    }

    @Override
    public double calcularValor() {
        return getValorBase() * 1.5;
    }
}