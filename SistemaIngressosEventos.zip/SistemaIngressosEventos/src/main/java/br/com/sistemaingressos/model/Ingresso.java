package br.com.sistemaingressos.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ingressos")
@TypeAlias("ingresso")
public abstract class Ingresso {

    @Id
    private String id;

    private String evento;
    private String comprador;
    private double valorBase;
    private String tipo;
    private StatusIngresso status;

    public Ingresso() {
        this.status = StatusIngresso.RESERVADO;
    }

    public Ingresso(String evento, String comprador, double valorBase) {
        this.evento = evento;
        this.comprador = comprador;
        this.valorBase = valorBase;
        this.status = StatusIngresso.RESERVADO;
    }

    public abstract double calcularValor();

    public String imprimirIngresso() {
        return "Evento: " + evento
                + " | Comprador: " + comprador
                + " | Tipo: " + tipo
                + " | Valor Final: R$ " + calcularValor()
                + " | Status: " + status;
    }

    // 🔥 Métodos de estado
    public void pagar() {
        this.status = StatusIngresso.PAGO;
    }

    public void cancelar() {
        this.status = StatusIngresso.CANCELADO;
    }

    public void usar() {
        this.status = StatusIngresso.UTILIZADO;
    }

    
    public String getId() { return id; }

    public String getEvento() { return evento; }
    public void setEvento(String evento) { this.evento = evento; }

    public String getComprador() { return comprador; }
    public void setComprador(String comprador) { this.comprador = comprador; }

    public double getValorBase() { return valorBase; }
    public void setValorBase(double valorBase) { this.valorBase = valorBase; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public StatusIngresso getStatus() { return status; }
    public void setStatus(StatusIngresso status) { this.status = status; }
}