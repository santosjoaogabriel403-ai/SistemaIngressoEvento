package br.com.sistemaingressos.controller;

import br.com.sistemaingressos.model.Reserva;
import br.com.sistemaingressos.service.ReservaService;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminController {

    private final ReservaService reservaService;

    public AdminController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @GetMapping("/admin")
    public String admin(Model model) {

        carregarDados(model);

        return "admin";
    }

    @PostMapping("/validar-ingresso")
    public String validarIngresso(
            @RequestParam String codigoQr,
            Model model
    ) {

        String mensagem = reservaService.validarIngresso(codigoQr);

        model.addAttribute("mensagem", mensagem);

        carregarDados(model);

        return "admin";
    }

    private void carregarDados(Model model) {

        List<Reserva> reservas = reservaService.listarTodasReservas();

        model.addAttribute("reservas", reservas);

        model.addAttribute("reservados",
                reservaService.totalReservados());

        model.addAttribute("confirmados",
                reservaService.totalConfirmados());

        model.addAttribute("utilizados",
                reservaService.totalUtilizados());

        model.addAttribute("cancelados",
                reservaService.totalCancelados());
    }
}