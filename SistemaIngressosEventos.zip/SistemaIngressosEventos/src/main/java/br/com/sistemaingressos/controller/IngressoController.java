package br.com.sistemaingressos.controller;

import br.com.sistemaingressos.model.Ingresso;
import br.com.sistemaingressos.model.IngressoDocumento;
import br.com.sistemaingressos.service.IngressoService;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class IngressoController {

    private final IngressoService service;

    public IngressoController(IngressoService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/cadastro")
    public String cadastro() {
        return "cadastro";
    }

    @PostMapping("/comprar")
    public String comprar(
            @RequestParam String evento,
            @RequestParam String comprador,
            @RequestParam double valorBase,
            @RequestParam String tipo,
            Model model
    ) {
        Ingresso ingresso = service.criarIngresso(tipo, evento, comprador, valorBase);

        model.addAttribute("ingresso", ingresso);
        model.addAttribute("valorFinal", ingresso.calcularValor());
        model.addAttribute("detalhes", ingresso.imprimirIngresso());

        return "resultado";
    }

    @GetMapping("/lista")
    public String lista(Model model) {
        List<IngressoDocumento> lista = service.listarTodos();
        model.addAttribute("ingressos", lista);
        return "lista";
    }
}