package br.com.sistemaingressos.service;

import br.com.sistemaingressos.model.Cliente;
import br.com.sistemaingressos.model.Evento;
import br.com.sistemaingressos.model.Reserva;
import br.com.sistemaingressos.model.StatusReserva;
import br.com.sistemaingressos.repository.ReservaRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class ReservaService {

    private final ReservaRepository reservaRepository;
    private final EventoService eventoService;

    public ReservaService(
            ReservaRepository reservaRepository,
            EventoService eventoService
    ) {
        this.reservaRepository = reservaRepository;
        this.eventoService = eventoService;
    }

    public String reservar(Cliente cliente, String eventoId) {

        Evento evento = eventoService.buscarPorId(eventoId);

        if (evento == null) {
            return "Evento não encontrado.";
        }

        if (evento.getQuantidadeDisponivel() <= 0) {
            return "Não há ingressos disponíveis.";
        }

        Reserva reservaExistente = reservaRepository
                .findByClienteIdAndEventoId(
                        cliente.getId(),
                        eventoId
                )
                .orElse(null);

        if (reservaExistente != null) {
            return "Você já possui reserva para este evento.";
        }

        String codigoQr = UUID.randomUUID().toString();

        Reserva reserva = new Reserva(
                cliente.getId(),
                cliente.getNome(),
                evento.getId(),
                evento.getNome(),
                evento.getValorIngresso(),
                codigoQr
        );

        reserva.confirmar();

        evento.setQuantidadeDisponivel(
                evento.getQuantidadeDisponivel() - 1
        );

        eventoService.salvar(evento);

        reservaRepository.save(reserva);

        return "Reserva realizada com sucesso.";
    }

    public List<Reserva> listarPorCliente(String clienteId) {
        return reservaRepository.findByClienteId(clienteId);
    }

    public Reserva buscarPorCodigoQr(String codigoQr) {
        return reservaRepository
                .findByCodigoQr(codigoQr)
                .orElse(null);
    }

    public String validarIngresso(String codigoQr) {

        Reserva reserva = buscarPorCodigoQr(codigoQr);

        if (reserva == null) {
            return "Ingresso não encontrado.";
        }

        if (reserva.getStatus() == StatusReserva.UTILIZADO) {
            return "Ingresso já utilizado.";
        }

        if (reserva.getStatus() == StatusReserva.CANCELADO) {
            return "Ingresso cancelado.";
        }

        reserva.utilizar();

        reservaRepository.save(reserva);

        return "Ingresso validado com sucesso.";
    }

    public List<Reserva> listarTodasReservas() {
        return reservaRepository.findAll();
    }

    public long totalReservados() {
        return reservaRepository.countByStatus(
                StatusReserva.RESERVADO
        );
    }

    public long totalConfirmados() {
        return reservaRepository.countByStatus(
                StatusReserva.CONFIRMADO
        );
    }

    public long totalUtilizados() {
        return reservaRepository.countByStatus(
                StatusReserva.UTILIZADO
        );
    }

    public long totalCancelados() {
        return reservaRepository.countByStatus(
                StatusReserva.CANCELADO
        );
    }
}