package br.com.sistemaingressos.model;

import org.springframework.data.annotation.TypeAlias;

@TypeAlias("normal")
public class IngressoNormal extends Ingresso {

    public IngressoNormal() {
        setTipo("Normal");
    }

    public IngressoNormal(String evento, String comprador, double valorBase) {
        super(evento, comprador, valorBase);
        setTipo("Normal");
    }

    @Override
    public double calcularValor() {
        return getValorBase();
    }
}