package br.com.sistemaingressos.controller;

import br.com.sistemaingressos.model.Cliente;
import br.com.sistemaingressos.model.Evento;
import br.com.sistemaingressos.service.EventoService;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EventoController {

    private final EventoService service;

    public EventoController(EventoService service) {
        this.service = service;
    }

    @GetMapping("/eventos")
    public String listarEventos(HttpSession session, Model model) {
        Cliente cliente = (Cliente) session.getAttribute("clienteLogado");

        if (cliente == null) {
            return "redirect:/login";
        }

        List<Evento> eventos = service.listarTodos();
        model.addAttribute("eventos", eventos);

        return "eventos";
    }
}