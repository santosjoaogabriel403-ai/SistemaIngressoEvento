package br.com.sistemaingressos.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ingressos_documentos")
public class IngressoDocumento {

    @Id
    private String id;

    private String evento;
    private String comprador;
    private double valorBase;
    private double valorFinal;
    private String tipo;
    private StatusIngresso status;

    public IngressoDocumento() {
    }

    public IngressoDocumento(Ingresso ingresso) {
        this.evento = ingresso.getEvento();
        this.comprador = ingresso.getComprador();
        this.valorBase = ingresso.getValorBase();
        this.valorFinal = ingresso.calcularValor();
        this.tipo = ingresso.getTipo();
        this.status = ingresso.getStatus();
    }

    public String getId() {
        return id;
    }

    public String getEvento() {
        return evento;
    }

    public String getComprador() {
        return comprador;
    }

    public double getValorBase() {
        return valorBase;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public String getTipo() {
        return tipo;
    }

    public StatusIngresso getStatus() {
        return status;
    }
}