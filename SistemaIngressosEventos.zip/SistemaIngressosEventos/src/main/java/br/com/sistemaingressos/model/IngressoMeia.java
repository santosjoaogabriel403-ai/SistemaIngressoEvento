package br.com.sistemaingressos.model;

import org.springframework.data.annotation.TypeAlias;

@TypeAlias("meia")
public class IngressoMeia extends Ingresso {

    public IngressoMeia() {
        setTipo("Meia-entrada");
    }

    public IngressoMeia(String evento, String comprador, double valorBase) {
        super(evento, comprador, valorBase);
        setTipo("Meia-entrada");
    }

    @Override
    public double calcularValor() {
        return getValorBase() / 2;
    }
}