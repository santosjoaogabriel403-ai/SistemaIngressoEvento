package br.com.sistemaingressos.model;

public enum StatusIngresso {
    RESERVADO,
    PAGO,
    CANCELADO,
    UTILIZADO
}