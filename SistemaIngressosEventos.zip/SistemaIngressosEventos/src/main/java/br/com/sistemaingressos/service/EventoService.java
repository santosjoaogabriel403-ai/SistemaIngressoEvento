package br.com.sistemaingressos.service;

import br.com.sistemaingressos.model.Evento;
import br.com.sistemaingressos.repository.EventoRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class EventoService {

    private final EventoRepository repository;

    public EventoService(EventoRepository repository) {
        this.repository = repository;
    }

    public List<Evento> listarTodos() {
        if (repository.count() == 0) {
            repository.save(new Evento("Show de Rock", "Evento musical ao vivo", "15/05/2026 20:00", "São Paulo", 100, 120.00));
            repository.save(new Evento("Festival Anime", "Evento para fãs de anime e cultura japonesa", "20/05/2026 14:00", "Jacareí", 80, 60.00));
            repository.save(new Evento("Stand-up Comedy", "Apresentação de comédia", "25/05/2026 21:00", "Teatro Central", 50, 45.00));
        }

        return repository.findAll();
    }

    public Evento buscarPorId(String id) {
        return repository.findById(id).orElse(null);
    }

    public Evento salvar(Evento evento) {
        return repository.save(evento);
    }
}