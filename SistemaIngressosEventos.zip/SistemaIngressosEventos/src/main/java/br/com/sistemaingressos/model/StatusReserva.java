package br.com.sistemaingressos.model;

public enum StatusReserva {
    RESERVADO,
    CONFIRMADO,
    UTILIZADO,
    CANCELADO
}
