package br.com.sistemaingressos.repository;

import br.com.sistemaingressos.model.Reserva;
import br.com.sistemaingressos.model.StatusReserva;
import java.util.List;
import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReservaRepository extends MongoRepository<Reserva, String> {

    List<Reserva> findByClienteId(String clienteId);

    Optional<Reserva> findByClienteIdAndEventoId(String clienteId, String eventoId);

    Optional<Reserva> findByCodigoQr(String codigoQr);

    List<Reserva> findByEventoId(String eventoId);

    long countByStatus(StatusReserva status);
}