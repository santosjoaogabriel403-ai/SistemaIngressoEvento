package br.com.sistemaingressos.controller;

import br.com.sistemaingressos.model.Cliente;
import br.com.sistemaingressos.model.Reserva;
import br.com.sistemaingressos.service.QrCodeService;
import br.com.sistemaingressos.service.ReservaService;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ReservaController {

    private final ReservaService service;
    private final QrCodeService qrCodeService;

    public ReservaController(
            ReservaService service,
            QrCodeService qrCodeService
    ) {
        this.service = service;
        this.qrCodeService = qrCodeService;
    }

    @PostMapping("/reservar")
    public String reservar(
            @RequestParam String eventoId,
            HttpSession session,
            Model model
    ) {

        Cliente cliente =
                (Cliente) session.getAttribute("clienteLogado");

        if (cliente == null) {
            return "redirect:/login";
        }

        String mensagem =
                service.reservar(cliente, eventoId);

        model.addAttribute("mensagem", mensagem);

        return "reserva-resultado";
    }

    @GetMapping("/meus-ingressos")
    public String meusIngressos(
            HttpSession session,
            Model model
    ) {

        Cliente cliente =
                (Cliente) session.getAttribute("clienteLogado");

        if (cliente == null) {
            return "redirect:/login";
        }

        List<Reserva> reservas =
                service.listarPorCliente(cliente.getId());

        for (Reserva reserva : reservas) {

            String qrBase64 =
                    qrCodeService.gerarQrCodeBase64(
                            reserva.getCodigoQr()
                    );

            model.addAttribute(
                    "qr_" + reserva.getId(),
                    qrBase64
            );
        }

        model.addAttribute("reservas", reservas);
        model.addAttribute("cliente", cliente);

        return "meus-ingressos";
    }
}