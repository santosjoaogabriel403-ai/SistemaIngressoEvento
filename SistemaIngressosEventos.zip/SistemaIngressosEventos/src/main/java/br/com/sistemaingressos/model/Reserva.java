package br.com.sistemaingressos.model;

import java.time.LocalDateTime;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "reservas")
public class Reserva {

    @Id
    private String id;

    private String clienteId;
    private String clienteNome;

    private String eventoId;
    private String eventoNome;

    private double valorIngresso;
    private StatusReserva status;
    private LocalDateTime dataReserva;

    private String codigoQr;

    public Reserva() {
    }

    public Reserva(String clienteId, String clienteNome, String eventoId, String eventoNome, double valorIngresso, String codigoQr) {
        this.clienteId = clienteId;
        this.clienteNome = clienteNome;
        this.eventoId = eventoId;
        this.eventoNome = eventoNome;
        this.valorIngresso = valorIngresso;
        this.codigoQr = codigoQr;
        this.status = StatusReserva.RESERVADO;
        this.dataReserva = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getClienteId() {
        return clienteId;
    }

    public String getClienteNome() {
        return clienteNome;
    }

    public String getEventoId() {
        return eventoId;
    }

    public String getEventoNome() {
        return eventoNome;
    }

    public double getValorIngresso() {
        return valorIngresso;
    }

    public StatusReserva getStatus() {
        return status;
    }

    public LocalDateTime getDataReserva() {
        return dataReserva;
    }

    public String getCodigoQr() {
        return codigoQr;
    }

    public void confirmar() {
        this.status = StatusReserva.CONFIRMADO;
    }

    public void utilizar() {
        this.status = StatusReserva.UTILIZADO;
    }

    public void cancelar() {
        this.status = StatusReserva.CANCELADO;
    }
}