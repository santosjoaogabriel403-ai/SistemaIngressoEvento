package br.com.sistemaingressos.repository;

import br.com.sistemaingressos.model.IngressoDocumento;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface IngressoRepository extends MongoRepository<IngressoDocumento, String> {
}