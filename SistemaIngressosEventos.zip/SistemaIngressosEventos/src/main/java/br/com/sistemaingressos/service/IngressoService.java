package br.com.sistemaingressos.service;

import br.com.sistemaingressos.model.Ingresso;
import br.com.sistemaingressos.model.IngressoDocumento;
import br.com.sistemaingressos.model.IngressoMeia;
import br.com.sistemaingressos.model.IngressoNormal;
import br.com.sistemaingressos.model.IngressoVIP;
import br.com.sistemaingressos.repository.IngressoRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class IngressoService {

    private final IngressoRepository repository;

    public IngressoService(IngressoRepository repository) {
        this.repository = repository;
    }

    public Ingresso criarIngresso(String tipo, String evento, String comprador, double valorBase) {

        Ingresso ingresso;

        if (tipo.equalsIgnoreCase("VIP")) {
            ingresso = new IngressoVIP(evento, comprador, valorBase);
        } else if (tipo.equalsIgnoreCase("MEIA")) {
            ingresso = new IngressoMeia(evento, comprador, valorBase);
        } else {
            ingresso = new IngressoNormal(evento, comprador, valorBase);
        }

        ingresso.pagar();

        IngressoDocumento documento = new IngressoDocumento(ingresso);
        repository.save(documento);

        return ingresso;
    }

    public List<IngressoDocumento> listarTodos() {
        return repository.findAll();
    }
}