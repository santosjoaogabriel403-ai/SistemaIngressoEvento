package br.com.sistemaingressos.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "eventos")
public class Evento {

    @Id
    private String id;

    private String nome;
    private String descricao;
    private String dataHorario;
    private String local;
    private int quantidadeDisponivel;
    private double valorIngresso;

    public Evento() {
    }

    public Evento(String nome, String descricao, String dataHorario, String local, int quantidadeDisponivel, double valorIngresso) {
        this.nome = nome;
        this.descricao = descricao;
        this.dataHorario = dataHorario;
        this.local = local;
        this.quantidadeDisponivel = quantidadeDisponivel;
        this.valorIngresso = valorIngresso;
    }

    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getDataHorario() {
        return dataHorario;
    }

    public String getLocal() {
        return local;
    }

    public int getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }

    public double getValorIngresso() {
        return valorIngresso;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setDataHorario(String dataHorario) {
        this.dataHorario = dataHorario;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public void setQuantidadeDisponivel(int quantidadeDisponivel) {
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    public void setValorIngresso(double valorIngresso) {
        this.valorIngresso = valorIngresso;
    }
}