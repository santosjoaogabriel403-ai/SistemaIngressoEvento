package br.com.sistemaingressos.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import javax.imageio.ImageIO;
import org.springframework.stereotype.Service;

@Service
public class QrCodeService {

    public String gerarQrCodeBase64(String texto) {

        try {
            QRCodeWriter qrCodeWriter = new QRCodeWriter();

            BitMatrix bitMatrix = qrCodeWriter.encode(
                    texto,
                    BarcodeFormat.QR_CODE,
                    200,
                    200
            );

            BufferedImage image = new BufferedImage(
                    200,
                    200,
                    BufferedImage.TYPE_INT_RGB
            );

            for (int x = 0; x < 200; x++) {
                for (int y = 0; y < 200; y++) {
                    image.setRGB(
                            x,
                            y,
                            bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF
                    );
                }
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "png", baos);

            return Base64.getEncoder().encodeToString(baos.toByteArray());

        } catch (Exception e) {
            return "";
        }
    }
}