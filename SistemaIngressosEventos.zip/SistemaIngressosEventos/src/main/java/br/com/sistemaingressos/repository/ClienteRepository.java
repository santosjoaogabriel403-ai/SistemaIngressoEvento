package br.com.sistemaingressos.repository;

import br.com.sistemaingressos.model.Cliente;
import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClienteRepository extends MongoRepository<Cliente, String> {

    Optional<Cliente> findByEmail(String email);
}