package br.com.sistemaingressos.controller;

import br.com.sistemaingressos.model.Cliente;
import br.com.sistemaingressos.service.ClienteService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ClienteController {

    private final ClienteService service;

    public ClienteController(ClienteService service) {
        this.service = service;
    }

    @GetMapping("/login")
    public String abrirLogin() {
        return "login";
    }

    @GetMapping("/cadastro-cliente")
    public String abrirCadastroCliente() {
        return "cadastro-cliente";
    }

    @PostMapping("/cadastro-cliente")
    public String cadastrarCliente(
            @RequestParam String nome,
            @RequestParam String email,
            @RequestParam String senha,
            HttpSession session
    ) {
        Cliente cliente = service.cadastrar(nome, email, senha);
        session.setAttribute("clienteLogado", cliente);
        return "redirect:/area-cliente";
    }

    @PostMapping("/login")
    public String login(
            @RequestParam String email,
            @RequestParam String senha,
            HttpSession session,
            Model model
    ) {
        Cliente cliente = service.login(email, senha);

        if (cliente == null) {
            model.addAttribute("erro", "Email ou senha inválidos");
            return "login";
        }

        session.setAttribute("clienteLogado", cliente);
        return "redirect:/area-cliente";
    }

    @GetMapping("/area-cliente")
    public String areaCliente(HttpSession session, Model model) {
        Cliente cliente = (Cliente) session.getAttribute("clienteLogado");

        if (cliente == null) {
            return "redirect:/login";
        }

        model.addAttribute("cliente", cliente);
        return "area-cliente";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}