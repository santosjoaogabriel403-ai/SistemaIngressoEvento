package br.com.sistemaingressos.repository;

import br.com.sistemaingressos.model.Evento;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EventoRepository extends MongoRepository<Evento, String> {
}
